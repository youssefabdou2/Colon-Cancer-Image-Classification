# colon cancer > 2025-09-04 5:03pm
https://universe.roboflow.com/youssef-iui59/colon-cancer-mnhkv-lshrq

Provided by a Roboflow user
License: CC BY 4.0

